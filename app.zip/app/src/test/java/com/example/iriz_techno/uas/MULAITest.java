package com.example.iriz_techno.uas;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by IRIZ_TECHNO on 21-Nov-19.
 */
public class MULAITest {
    @Test
    public void onCreate() throws Exception {

    }

}