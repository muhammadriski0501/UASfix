package com.example.iriz_techno.uas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SOAL3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soal3);

        Button btn_8 = (Button) findViewById(R.id.b_8);

        btn_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent7 = new Intent(SOAL3.this,SOAL4.class);
                startActivity(intent7);
            }}
        );

        Button btn_12 = (Button) findViewById(R.id.b_12);

        btn_12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent8 = new Intent(SOAL3.this,GAGAL.class);
                startActivity(intent8);
            }}
        );
    }
}
