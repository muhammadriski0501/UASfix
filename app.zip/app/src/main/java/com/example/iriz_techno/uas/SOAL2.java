package com.example.iriz_techno.uas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SOAL2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soal2);

        Button btn_soekarno = (Button) findViewById(R.id.b_karno);

        btn_soekarno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent5 = new Intent(SOAL2.this,SOAL3.class);
                startActivity(intent5);
            }}
        );

        Button btn_hata = (Button) findViewById(R.id.b_hata);

        btn_hata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent6 = new Intent(SOAL2.this,GAGAL.class);
                startActivity(intent6);
            }}
        );
    }
}
