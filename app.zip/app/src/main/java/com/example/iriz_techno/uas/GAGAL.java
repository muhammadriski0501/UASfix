package com.example.iriz_techno.uas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GAGAL extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gagal);

        Button btn_home = (Button) findViewById(R.id.b_home);

        btn_home.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent intent11 = new Intent(GAGAL.this, MainActivity.class);
                                            startActivity(intent11);
                                        }
                                    }
        );

        Button btn_mulailagi = (Button) findViewById(R.id.b_mulailagi);

        btn_mulailagi.setOnClickListener(new View.OnClickListener() {
                                             @Override
                                             public void onClick(View v) {
                                                 Intent intent11 = new Intent(GAGAL.this, MULAI.class);
                                                 startActivity(intent11);
                                             }
                                         }
        );
    }
}
