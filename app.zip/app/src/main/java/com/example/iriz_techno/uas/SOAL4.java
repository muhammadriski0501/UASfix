package com.example.iriz_techno.uas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SOAL4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soal4);

        Button btn_suharto = (Button) findViewById(R.id.b_8);

        btn_suharto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent7 = new Intent(SOAL4.this,GAGAL.class);
                startActivity(intent7);
            }}
        );

        Button btn_habibi = (Button) findViewById(R.id.b_12);

        btn_habibi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent8 = new Intent(SOAL4.this,SOAL5.class);
                startActivity(intent8);
            }}
        );
    }
}
