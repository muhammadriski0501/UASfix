package com.example.iriz_techno.uas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SOAL5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soal5);

        Button btn_soeharto = (Button) findViewById(R.id.b_8);

        btn_soeharto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent9 = new Intent(SOAL5.this,BERHASIL.class);
                startActivity(intent9);
            }}
        );

        Button btn_habibie = (Button) findViewById(R.id.b_12);

        btn_habibie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent10 = new Intent(SOAL5.this,GAGAL.class);
                startActivity(intent10);
            }}
        );
    }
}
