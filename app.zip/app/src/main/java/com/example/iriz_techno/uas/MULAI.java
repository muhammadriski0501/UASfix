package com.example.iriz_techno.uas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MULAI extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mulai);


        Button btn_ponogoro = (Button) findViewById(R.id.b_ponogoro);

        btn_ponogoro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent4 = new Intent(MULAI.this,SOAL2.class);
                startActivity(intent4);
            }}
        );

        Button btn_patimura = (Button) findViewById(R.id.b_patimura);

        btn_patimura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(MULAI.this,GAGAL.class);
                startActivity(intent3);
            }}
        );
    }
}
