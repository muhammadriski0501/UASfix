package com.example.iriz_techno.uas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class materi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materi);

        Button btn_diponogoro = (Button) findViewById(R.id.b_diponogoro);

        btn_diponogoro .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(materi.this, DIPONOGORO.class);
                startActivity(intent);
            } }
        );

        Button btn_soekarno = (Button) findViewById(R.id.b_soekarno);

        btn_soekarno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(materi.this,SOEKARNO.class);
                startActivity(intent2);
            }}
        );

        Button btn_habibie = (Button) findViewById(R.id.b_habibie);

        btn_habibie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(materi.this,habibi.class);
                startActivity(intent2);
            }}
        );

        Button btn_soeharto = (Button) findViewById(R.id.b_soeharto);

        btn_soeharto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(materi.this,SOEHARTO.class);
                startActivity(intent2);
            }}
        );

        Button btn_patimura = (Button) findViewById(R.id.b_patimura);

        btn_patimura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(materi.this,PATIMURA.class);
                startActivity(intent2);
            }}
        );

        Button btn_hatta = (Button) findViewById(R.id.b_hatta);

        btn_hatta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(materi.this,HATTA.class);
                startActivity(intent2);
            }}
        );
    }
}
